/*
** $Id: tools.h,v 1.1.1.1 2005/06/14 04:38:33 svitak Exp $
** $Log: tools.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:33  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1992/12/11 19:06:19  dhb
** Initial revision
**
*/

#define MAX_EL_SIZE 5000
#define SMALL_EL_SIZE 500
