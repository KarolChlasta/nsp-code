/* $Id: out_defs.h,v 1.1.1.1 2005/06/14 04:38:28 svitak Exp $ */

/* Version EDS21b 96/08/02, Erik De Schutter, BBF-UIA 8/96-8/96 */

/*
** $Log: out_defs.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:28  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1997/05/29 08:45:29  dhb
** Initial revision
**
*/

#define SPIKESAVE -1
