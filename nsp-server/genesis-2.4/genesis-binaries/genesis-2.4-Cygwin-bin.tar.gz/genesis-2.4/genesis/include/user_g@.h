#define pulsegen_INPUT 0
#define pulsegen_LEVEL 1
#define pulsegen_WIDTH 2
#define pulsegen_DELAY 3
#define PID_CMD 0
#define PID_SNS 1
#define PID_GAIN 2
