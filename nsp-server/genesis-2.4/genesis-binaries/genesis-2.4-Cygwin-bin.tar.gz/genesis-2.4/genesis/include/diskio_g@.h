#define FLUSH 1001
#define UPDATE 10010
#define diskio_SAVE 0
#define variable_SAVE 0
#define metadata_SAVE 0
